console.log("Javascript is succesvol gedownload.");

//Functies voor cookies
function setCookie(cname, cvalue, exdays) {
  var d = new Date();

  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  var expires = "expires=" + d.toGMTString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkCookie() {
  var user = getCookie("username");
  if (user != "") {
    alert("Welcome again " + user);
  } else {
    user = prompt("Please enter your name:", "");
    if (user != "" && user != null) {
      setCookie("username", user, 30);
    }
  }
}

//Functie voor card verandering

var request = new XMLHttpRequest();
request.open("GET", "http://localhost:3000/products", false);
request.send(null);
var myObj = JSON.parse(request.responseText);
console.log(myObj);


function cardChange() {
  for (i = 0; i < myObj.length; i++) {
    (function (i) {
      var div = document.createElement('div');
      div.setAttribute('class', 'slide');
      div.innerHTML = `
                    <div class="view overlay">
                      <img id="cardImage" class="card-img-top" alt="Card image cap" src="${myObj[i].foto}">
                      <a href="#!">
                       <div class="mask rgba-white-slight"></div>
                      </a>
                    </div>
                    <div class="card-body">
                      <h4 id="cardTitle" class="card-title">${myObj[i].naam}</h4>
                      <h6 id="prijs" class="card-title">${myObj[i].prijs}</h6>
                      <!-- Text -->
                      <p id="beschrijving" class="card-text">${myObj[i].beschrijving}</p>
                        <!-- Button -->
                      <a href="#" class="btn btn-primary">Button</a>
                    </div>
                    `;
      document.getElementById('slides').appendChild(div);
    })(i);

  }
}
cardChange();

var slides = document.querySelectorAll('#slides .slide');
var currentSlide = 0;
var slideInterval = setInterval(nextSlide, 5000);

function nextSlide() {
  slides[currentSlide].className = 'slide';
  currentSlide = (currentSlide + 1) % slides.length;
  slides[currentSlide].className = 'slide showing';
}


function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

function cardChange2() {
  for (i = 0; i < myObj.length; i++) {
    sleep(4000);
    switch (myObj[i]) {
      case myObj[0]:
        /*document.getElementById("cardImage2").src = 'myObj[0].foto';*/
        document.getElementById("cardTitle2").innerHTML = myObj[0].naam;
        document.getElementById("prijs2").innerHTML = myObj[0].prijs;
        document.getElementById("beschrijving2").innerHTML = myObj[0].beschrijving;
        break;
      case (myObj[1]):
        /*document.getElementById("cardImage").src = 'myObj[1].foto';*/
        document.getElementById("cardTitle2").innerHTML = myObj[1].naam;
        document.getElementById("prijs2").innerHTML = myObj[1].prijs;
        document.getElementById("beschrijving2").innerHTML = myObj[1].beschrijving;
        break;
      case (myObj[2]):
        /*document.getElementById("cardImage").src = 'myObj[2].foto';*/
        document.getElementById("cardTitle2").innerHTML = myObj[2].naam;
        document.getElementById("prijs2").innerHTML = myObj[2].prijs;
        document.getElementById("beschrijving2").innerHTML = myObj[2].beschrijving;
        break;
      case (myObj[3]):
        /*document.getElementById("cardImage").src = 'myObj[3].foto';*/
        document.getElementById("cardTitle2").innerHTML = myObj[3].naam;
        document.getElementById("prijs2").innerHTML = myObj[3].prijs;
        document.getElementById("beschrijving2").innerHTML = myObj[3].beschrijving;
        break;
      default:
        console.log("Je functie werkt niet goed.");
        break;
    }
  }
}






