switch (myObj[i]) {
            case myObj[0]:
                /*document.getElementById("cardImage").src = 'myObj[0].foto';*/
                document.getElementById("cardTitle").innerHTML = myObj[0].naam;
                document.getElementById("prijs").innerHTML = myObj[0].prijs;
                document.getElementById("beschrijving").innerHTML = myObj[0].beschrijving;
                break;
            case (myObj[1]):
                /*document.getElementById("cardImage").src = 'myObj[1].foto';*/
                document.getElementById("cardTitle").innerHTML = myObj[1].naam;
                document.getElementById("prijs").innerHTML = myObj[1].prijs;
                document.getElementById("beschrijving").innerHTML = myObj[1].beschrijving;
                break;
            case (myObj[2]):
                /*document.getElementById("cardImage").src = 'myObj[2].foto';*/
                document.getElementById("cardTitle").innerHTML = myObj[2].naam;
                document.getElementById("prijs").innerHTML = myObj[2].prijs;
                document.getElementById("beschrijving").innerHTML = myObj[2].beschrijving;
                break;
            case (myObj[3]):
                /*document.getElementById("cardImage").src = 'myObj[3].foto';*/
                document.getElementById("cardTitle").innerHTML = myObj[3].naam;
                document.getElementById("prijs").innerHTML = myObj[3].prijs;
                document.getElementById("beschrijving").innerHTML = myObj[3].beschrijving;
                break;
            default:
                console.log("Je functie werkt niet goed.");
                break;
        }





        var list = [1, 2, 3, 4, 5];

        for (var i = 0, len = list.length; i < len; i += 1) {
            (function(i) {
                setInterval(function() {
                    list[i] += 10;
                    console.log(i + "=>" + list[i] + "\n");
                }, 5000)
            })(i);
        }
      

        function cardChange() {
            for (i = 0; i < myObj.length; i++) {
              (function (i) {
                var div = document.createElement('div');
                div.setAttribute('class', 'card');
                div.innerHTML = `
                    <div class="view overlay">
                      <img id="cardImage" class="card-img-top" alt="Card image cap">
                      <a href="#!">
                       <div class="mask rgba-white-slight"></div>
                      </a>
                    </div>
                    <div class="card-body">
                      <h4 id="cardTitle" class="card-title">${myObj[i].naam}</h4>
                      <h6 id="prijs" class="card-title">${myObj[i].prijs}</h6>
                      <!-- Text -->
                      <p id="beschrijving" class="card-text">${myObj[i].beschrijving}</p>
                        <!-- Button -->
                      <a href="#" class="btn btn-primary">Button</a>
                    </div>
                    `;
                document.getElementById('mijnCard').appendChild(div);
              })
              (i);
            }
          }
          cardChange();
          